#pragma once

class Complex {
    public:
    double Re, Im;

    Complex(double Re, double Im);

    //TODO
};


//为虚数单位i定义字面量
Complex operator"" i(unsigned long long Im) {
    //TODO: 返回一个Complex对象
}

Complex operator"" i(long double Im) {
    //TODO: 返回一个Complex对象
}
