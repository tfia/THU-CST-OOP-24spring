template <class RealShape>
class Shape {
protected:
    int a, b;
public:
    std::string type();
    int area();
    // print();
    // zoom(int k);
    // int getCreate();
    // int getAlive();
};

class Triangle;

class Rectangle;