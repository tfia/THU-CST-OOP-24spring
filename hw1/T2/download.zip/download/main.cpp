#include "functions.h"
#include <iostream>
using namespace std;

int main()
{
	int a, b;
	cin >> a >> b;
	cout << sum(a, b) << endl;
	cout << product(a, b) << endl;
	return 0;
}
