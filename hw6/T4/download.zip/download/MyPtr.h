#pragma once
#include <iostream>
using namespace std;

struct Counter {
public:
    int s, w;
    Counter(int _s = 0, int _w = 0) : s(_s), w(_w) {}
};


template <class T> class MyWeakPtr;
template <class T>
class MySharedPtr {
private:
    T *data;
    Counter *refCount;
    void release();
public:
    MySharedPtr();
    MySharedPtr(T *p);
    MySharedPtr(MySharedPtr<T> &&sp);
    MySharedPtr(const MyWeakPtr<T> &wp);
    MySharedPtr(const MySharedPtr<T> &sp);
    ~MySharedPtr();
    MySharedPtr<T>& operator= (MySharedPtr<T> &&sp);
    MySharedPtr<T>& operator= (const MySharedPtr<T> &sp);

    int use_count();
    T& operator* ();
    T* operator-> ();

    friend class MyWeakPtr<T>;
};



template <class T>
class MyWeakPtr {
private:
    Counter *refCount;
    T *data;
    void release();
public:
    MyWeakPtr();
    MyWeakPtr(MySharedPtr<T> &sp);
    MyWeakPtr(const MyWeakPtr &wp);
    MyWeakPtr(MyWeakPtr &&wp);
    ~MyWeakPtr();

    MyWeakPtr<T>& operator= (const MyWeakPtr<T> &wp);

    MyWeakPtr<T>& operator= (const MySharedPtr<T> &sp);

    MyWeakPtr<T>& operator= (MyWeakPtr<T> &&wp);

    bool expired();
    MySharedPtr<T> lock();

    int use_count();

    friend class MySharedPtr<T>;
};
