#pragma once

#include <string>

#include "Hash.h"

template <typename T1, typename T2>
class HashTable
{
public:
    void addItem(const T1 &key, const T2 &value);
    void removeItem(const T1 &key);
    T2 *findByKey(const T1 &key);
};
